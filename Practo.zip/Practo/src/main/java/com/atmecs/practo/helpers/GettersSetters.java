package com.atmecs.practo.helpers;

import java.util.Properties;

public class GettersSetters {
String data;
 Properties properties;
 String homepage;
public String getData() {
	return data;
}

public String setData(String data) {
homepage=properties.getProperty(data);
return homepage;

}










}
